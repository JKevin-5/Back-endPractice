package com.test.entity;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author Jkevin
 * @date 2022年10月12日 0:25
 */
@Data
@AllArgsConstructor
public class Borrow {
    private int id;
    private int uid;
    private int bid;
}
