package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudStudyApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringCloudStudyApplication.class, args);
    }

}
